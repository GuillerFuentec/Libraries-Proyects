import "./App.css";
import "./assets/media/css/theme.css";
import Layout from "./assets/Layout";

export default function App() {
  return (
    <>

      <Layout />
    </>
  );
}
