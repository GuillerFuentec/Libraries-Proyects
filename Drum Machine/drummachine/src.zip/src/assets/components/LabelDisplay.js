export default function LabelDisplay({children}) {
  return <label className="mx-auto">{children}</label>;
}
