

export default function ToggleDisplay() {
  return (
    <>
      <input type="checkbox" className="toggle [--tglbg:white] opacity-20"/>
    </>
  );
}
